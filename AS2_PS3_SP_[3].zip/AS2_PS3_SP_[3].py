# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 17:21:14 2019

@author: Sai Kiran
"""

from collections import namedtuple, deque
import time

 
inf = float('inf')
Edge = namedtuple('Edge', 'start,end,cost')
 
class ShortestDistance():
    def __init__(self, edges):
        self.edges  = [Edge(*edge) for edge in edges]
        self.vertices = {e.start for e in self.edges} | {e.end for e in self.edges}
        
 
    def processDijkstra(self, source, dest):
        assert source in self.vertices
        dist = {vertex: inf for vertex in self.vertices}
        previous = {vertex: None for vertex in self.vertices}
        dist[source] = 0
        q = self.vertices.copy()
        neighbours = {vertex: set() for vertex in self.vertices}
        for start, end, cost in self.edges:
            neighbours[start].add((end, cost))
        #pp(neighbours)
 
        while q:
            u = min(q, key=lambda vertex: dist[vertex])
            q.remove(u)
            if dist[u] == inf or u == dest:
                break
            for v, cost in neighbours[u]:
                alt = dist[u] + cost
                if alt < dist[v]:                                  # Relax (u,v,a)
                    dist[v] = alt
                    previous[v] = u
        #pp(previous)
        s, u = deque(), dest
        while previous[u]:
            s.appendleft(u)
            u = previous[u]
        s.appendleft(u)
        return [s,dist[dest]]
    
def main():
    startTime=time.time()
    nodelist=[]
    
    with open("C:\\inputPS3.txt",'r') as filehandle:
        for line in filehandle:
            if("DC Node" in line):
                dcNode,source =line.split(":")
            elif("WH Node" in line):
                whareHouseNode,destination=line.split(":")
            elif("/" in line):
                startNode,endNode,value = line.split("/")
                nodelist.append((startNode,endNode,int(value)))
    shortestPath = ShortestDistance(nodelist)
    source=source.rstrip("\r\n")
    destination=destination.rstrip("\r\n")
    output=shortestPath.processDijkstra(source.rstrip("\r\n"),destination.rstrip("\r\n"))
    finalPath=list(output[0])
    distanceTravel=output[1]
    startTimeinhrs=10
    speedofTruck=60
    timeTaken=(distanceTravel/speedofTruck)*60
    outputFile= open(r"outputPS3.txt","w+")
    finalDecesion="Shortest route from DC {0} to reach Warehouse {1} is {2} \n and it has minimum travel distance {3} km \n it will take him {4} minutes to reach \n Expected arrival time at the warehouse is {5}:{6} am".format(source,destination,finalPath,distanceTravel,timeTaken,startTimeinhrs,timeTaken)
    outputFile.write(finalDecesion)
    outputFile.close()
    endTime=time.time()
    print("Total process time: ",(endTime - startTime))


if __name__ == '__main__':
    main()
   
    
    
""" 
nodelist=[]
with open("C:\\Users\\Sai Kiran\\Desktop\\inputPS3.txt",'r') as filehandle:
    for line in filehandle:
        if("DC Node" in line):
            dcNode,source =line.split(":")
        elif("WH Node" in line):
            whareHouseNode,destination=line.split(":")
        elif("/" in line):
            startNode,endNode,value = line.split("/")
            nodelist.append((startNode,endNode,int(value)))
			

shortestPath = ShortestDistance(nodelist)
source=source.rstrip("\r\n")
destination=destination.rstrip("\r\n")
output=shortestPath.processDijkstra(source.rstrip("\r\n"),destination.rstrip("\r\n"))
finalPath=output[0]
distanceTravel=output[1]
startTimeinhrs=10
speedofTruck=60
timeTaken=(distanceTravel/speedofTruck)*60

print("Shortest route from DC {0} to reach Warehouse {1} is {2} and it has minimum travel distance {3} km it will take him {4} minutes to reach Expected arrival time at the warehouse is{5}:{6} am".format(source,destination,finalPath,distanceTravel,timeTaken,startTimeinhrs,timeTaken))
"""
"""
Shortest route from DC 'a' to reach Warehouse 'j' is
and it has minimum travel distance 18km
it will take him 18 minutes to reach
Expected arrival time at the warehouse is 10:18am
"""
